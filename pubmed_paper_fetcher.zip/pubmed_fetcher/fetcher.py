import requests
import csv

def fetch_papers(query: str, max_results: int = 10):
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    params = {
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": max_results
    }
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()
    ids = data["esearchresult"].get("idlist", [])
    return ids

def save_to_csv(pubmed_ids, filename):
    with open(filename, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["PubMedID"])
        for pid in pubmed_ids:
            writer.writerow([pid])
