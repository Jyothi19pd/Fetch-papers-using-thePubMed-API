import argparse
from pubmed_fetcher.fetcher import fetch_papers, save_to_csv

def main():
    parser = argparse.ArgumentParser(description="Fetch PubMed papers")
    parser.add_argument("query", help="Search query for PubMed")
    parser.add_argument("-f", "--file", default="results.csv", help="Output CSV filename")
    args = parser.parse_args()

    pubmed_ids = fetch_papers(args.query)
    save_to_csv(pubmed_ids, args.file)
    print(f"Saved {len(pubmed_ids)} papers to {args.file}")

if __name__ == "__main__":
    main()
