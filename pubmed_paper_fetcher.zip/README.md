# PubMed Paper Fetcher

This tool allows you to fetch PubMed paper IDs for a given search query and save them as a CSV.

## How to Use

```bash
python main.py "cancer genomics" -f papers.csv
```

This will save paper IDs into `papers.csv`.
